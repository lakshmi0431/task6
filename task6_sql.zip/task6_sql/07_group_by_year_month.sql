SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month
FROM orders
GROUP BY Year, Month;