SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
SUM(amount) AS Revenue,
COUNT(DISTINCT order_id) AS Orders
FROM orders
GROUP BY Year, Month
ORDER BY Year, Month
LIMIT 3;