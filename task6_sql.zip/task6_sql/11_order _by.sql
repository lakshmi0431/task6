-- Ascending Order
SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
SUM(amount) AS Revenue
FROM orders
GROUP BY Year, Month
ORDER BY Year, Month;

-- Descending Order
SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
SUM(amount) AS Revenue
FROM orders
GROUP BY Year, Month
ORDER BY Year DESC, Month DESC;