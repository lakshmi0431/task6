SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
SUM(amount) AS Total_Revenue
FROM orders
GROUP BY Year, Month;