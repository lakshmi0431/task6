SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
COUNT(DISTINCT order_id) AS Order_Volume
FROM orders
GROUP BY Year, Month;