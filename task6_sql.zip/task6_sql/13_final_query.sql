SELECT
EXTRACT(YEAR FROM order_date) AS Year,
EXTRACT(MONTH FROM order_date) AS Month,
SUM(amount) AS Total_Revenue,
COUNT(DISTINCT order_id) AS Order_Volume
FROM orders
GROUP BY Year, Month
ORDER BY Year, Month;