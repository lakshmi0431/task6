-- Extract the Month from the Date
SELECT
order_id,
order_date,
EXTRACT(MONTH FROM order_date) AS Month
FROM orders;